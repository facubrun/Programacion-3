/*
  Módulo de implementación de `sistema'.

  Laboratorio de Programación 3.
  InCo-FIng-UDELAR
 */

#include "../include/sistema.h"

matriz_t max_datos_procesados(nat n, nat* datos, nat* rendimiento) {
	matriz_t OPT = crear_matriz(n+1, n+1);
	return OPT;
}

Lista planificacion_optima(nat n, matriz_t OPT) {
	Lista reinicios = crear_lista();
	return reinicios;
}

